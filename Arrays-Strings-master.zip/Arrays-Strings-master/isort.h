#define SIZE 50

void shift_element(int* arr, int i);

void insertion_sort(int* arr, int i);

void printIntArray(int arr[], int length);